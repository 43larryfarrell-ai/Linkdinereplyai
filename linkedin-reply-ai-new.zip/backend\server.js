/**
 * LinkedIn Reply AI Backend Server
 * 
 * Secure backend API that proxies requests to Gemini API
 * Features:
 * - Environment variable configuration
 * - Rate limiting
 * - CORS protection
 * - Input validation
 * - Error handling
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const Flutterwave = require('flutterwave-node-v3');

const app = express();
// Render uses PORT environment variable, defaults to 3000 for local dev
const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const FLUTTERWAVE_SECRET_KEY = process.env.FLUTTERWAVE_SECRET_KEY;
const FLUTTERWAVE_PUBLIC_KEY = process.env.FLUTTERWAVE_PUBLIC_KEY;
const NODE_ENV = process.env.NODE_ENV || 'development';

// Initialize Flutterwave
const flw = new Flutterwave(FLUTTERWAVE_PUBLIC_KEY, FLUTTERWAVE_SECRET_KEY);

// Validate required environment variables
if (!GEMINI_API_KEY) {
  console.error('ERROR: GEMINI_API_KEY environment variable is required!');
  console.error('Please create a .env file with GEMINI_API_KEY=your_key');
  process.exit(1);
}

if (!FLUTTERWAVE_SECRET_KEY) {
  console.error('ERROR: FLUTTERWAVE_SECRET_KEY environment variable is required!');
  console.error('Please create a .env file with FLUTTERWAVE_SECRET_KEY=your_key');
  process.exit(1);
}

if (!FLUTTERWAVE_PUBLIC_KEY) {
  console.error('ERROR: FLUTTERWAVE_PUBLIC_KEY environment variable is required!');
  console.error('Please create a .env file with FLUTTERWAVE_PUBLIC_KEY=your_key');
  process.exit(1);
}

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
  crossOriginEmbedderPolicy: false
}));

// CORS configuration
const allowedOrigins = process.env.ALLOWED_ORIGINS 
  ? process.env.ALLOWED_ORIGINS.split(',').map(origin => origin.trim())
  : ['*'];

const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps, Postman, or Chrome extensions)
    if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  optionsSuccessStatus: 200
};

app.use(cors(corsOptions));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting configuration
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes default
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // 100 requests per window
  message: {
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Apply rate limiting to all routes
app.use('/api/', limiter);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: NODE_ENV 
  });
});

// Gemini API configuration
const GEMINI_API_VERSION = 'v1';
const GEMINI_MODEL_OPTIONS = [
  'gemini-2.5-flash',
  'gemini-2.0-flash-exp',
  'gemini-1.5-flash',
  'gemini-1.5-pro',
  'gemini-pro'
];

/**
 * Generate replies using Gemini API with model fallback
 */
async function generateRepliesWithGemini(pageText) {
  const prompt = `Generate 3 short, polite, professional LinkedIn reply suggestions (1-3 sentences each) for this post content: ${pageText}. Make them engaging and relevant. Format each reply on a new line, numbered 1, 2, 3.`;

  const requestBody = {
    contents: [{
      parts: [{
        text: prompt
      }]
    }]
  };

  let lastError = null;
  const triedModels = [];

  // Try each model option until one works
  for (const model of GEMINI_MODEL_OPTIONS) {
    const apiUrl = `https://generativelanguage.googleapis.com/${GEMINI_API_VERSION}/models/${model}:generateContent?key=${GEMINI_API_KEY}`;
    triedModels.push(model);

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData.error?.message || `API error: ${response.status}`;

        // Check if it's a model not found error
        if (errorMessage.includes('not found') || errorMessage.includes('not supported')) {
          lastError = new Error(`Model "${model}" is not available. Trying fallback models...`);
          console.warn(`Model ${model} not found, trying next model...`);
          continue;
        }

        lastError = new Error(errorMessage);
        continue;
      }

      const data = await response.json();

      if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || 
          !data.candidates[0].content.parts || !data.candidates[0].content.parts[0]) {
        lastError = new Error('Invalid API response format');
        continue;
      }

      // Success! Return the result
      console.log(`Successfully used model: ${model}`);
      return {
        text: data.candidates[0].content.parts[0].text,
        model: model
      };
    } catch (error) {
      console.error(`Error with model ${model}:`, error.message);
      lastError = error;
      continue;
    }
  }

  // If we get here, all models failed
  const errorMsg = `Unable to connect to Gemini API. Tried models: ${triedModels.join(', ')}. ` +
    `Error: ${lastError?.message || 'Unknown error'}`;
  throw new Error(errorMsg);
}

/**
 * POST /api/generate-reply
 * Generate LinkedIn reply suggestions
 */
app.post('/api/generate-reply', 
  [
    // Input validation
    body('pageText')
      .trim()
      .isLength({ min: 50, max: 1500 })
      .withMessage('Page text must be between 50 and 1500 characters')
      .escape() // Sanitize input
  ],
  async (req, res) => {
    try {
      // Check validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const { pageText } = req.body;

      // Generate replies using Gemini API
      const result = await generateRepliesWithGemini(pageText);

      // Return success response
      res.json({
        success: true,
        text: result.text,
        model: result.model,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error('Error generating replies:', error);

      // Don't expose internal error details in production
      const errorMessage = NODE_ENV === 'production' 
        ? 'Failed to generate replies. Please try again later.'
        : error.message;

      res.status(500).json({
        error: 'Internal server error',
        message: errorMessage
      });
    }
  }
);

/**
 * POST /api/flutterwave/create-payment
 * Create Flutterwave payment link
 */
app.post('/api/flutterwave/create-payment',
  [
    // Input validation
    body('amount').isFloat({ min: 1 }).withMessage('Amount must be a positive number'),
    body('currency').isLength({ min: 3, max: 3 }).withMessage('Currency must be 3 characters'),
    body('email').isEmail().withMessage('Valid email is required'),
    body('tx_ref').isLength({ min: 1 }).withMessage('Transaction reference is required'),
    body('plan_type').isIn(['monthly', 'yearly', 'lifetime']).withMessage('Invalid plan type'),
    body('description').isLength({ min: 1 }).withMessage('Description is required')
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const { amount, currency, email, tx_ref, plan_type, description } = req.body;

      // Create payment link with Flutterwave
      const payload = {
        tx_ref: tx_ref,
        amount: amount,
        currency: currency,
        payment_options: 'card, ussd, mobilemoney, banktransfer',
        redirect_url: `${req.protocol}://${req.get('host')}/flutterwave/callback`,
        customer: {
          email: email,
          name: 'LinkedIn Reply AI User'
        },
        customizations: {
          title: 'LinkedIn Reply AI',
          description: description,
          logo: 'https://your-domain.com/logo.png' // TODO: Update with your logo URL
        }
      };

      const response = await flw.Charge.payment_link(payload);

      if (response.status === 'success') {
        res.json({
          success: true,
          data: {
            link: response.data.link,
            tx_ref: response.data.tx_ref
          },
          timestamp: new Date().toISOString()
        });
      } else {
        throw new Error(response.message || 'Failed to create payment link');
      }

    } catch (error) {
      console.error('Error creating Flutterwave payment:', error);

      const errorMessage = NODE_ENV === 'production' 
        ? 'Failed to create payment. Please try again later.'
        : error.message;

      res.status(500).json({
        error: 'Internal server error',
        message: errorMessage
      });
    }
  }
);

/**
 * POST /api/flutterwave/webhook
 * Handle Flutterwave webhook events
 */
app.post('/api/flutterwave/webhook', (req, res) => {
  try {
    const webhookHash = process.env.FLUTTERWAVE_WEBHOOK_HASH;
    const secretHash = req.headers['verif-hash'];

    // Verify webhook signature
    if (!secretHash || (secretHash !== webhookHash)) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const event = req.body;
    console.log('Flutterwave webhook received:', event);

    // Handle successful payment
    if (event.event === 'charge.completed' && event.data.status === 'successful') {
      const { tx_ref, customer, amount } = event.data;
      
      // Extract plan type from transaction reference
      const planType = tx_ref.split('-')[2]; // Format: pro-upgrade-{planType}-{timestamp}
      
      console.log(`Payment successful: ${planType} plan for ${customer.email}, Amount: ${amount}`);
      
      // TODO: Update user's pro status in your database
      // This would typically involve:
      // 1. Finding the user by email or extension ID
      // 2. Updating their subscription status
      // 3. Setting expiration date for monthly/yearly plans
      
      // For now, we'll just log the successful payment
      // In a real implementation, you'd store this in your database
    }

    res.status(200).json({ received: true });

  } catch (error) {
    console.error('Error processing Flutterwave webhook:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

/**
 * GET /flutterwave/callback
 * Handle Flutterwave payment callback
 */
app.get('/flutterwave/callback', (req, res) => {
  const { status, tx_ref, transaction_id } = req.query;
  
  // Redirect back to extension with status
  // In a real implementation, you might want to show a success/failure page
  if (status === 'successful') {
    res.redirect(`https://your-extension-domain.com/success?tx_ref=${tx_ref}`);
  } else {
    res.redirect(`https://your-extension-domain.com/failure?tx_ref=${tx_ref}`);
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not found',
    message: 'The requested endpoint does not exist'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  
  res.status(err.status || 500).json({
    error: 'Internal server error',
    message: NODE_ENV === 'production' 
      ? 'An unexpected error occurred'
      : err.message
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 LinkedIn Reply AI Backend Server running on port ${PORT}`);
  console.log(`📝 Environment: ${NODE_ENV}`);
  console.log(`🔒 CORS: ${allowedOrigins.includes('*') ? 'All origins' : allowedOrigins.join(', ')}`);
  console.log(`⏱️  Rate limit: ${process.env.RATE_LIMIT_MAX_REQUESTS || 100} requests per ${(parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000) / 60000} minutes`);
  
  if (NODE_ENV === 'development') {
    console.log(`\n⚠️  Running in DEVELOPMENT mode`);
    console.log(`   Health check: http://localhost:${PORT}/health`);
    console.log(`   API endpoint: http://localhost:${PORT}/api/generate-reply\n`);
  }
});

module.exports = app;

